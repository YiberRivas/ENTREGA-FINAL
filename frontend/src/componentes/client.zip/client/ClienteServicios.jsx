// src/pages/cliente/ClienteServicios.jsx
import { useEffect, useState } from "react";
import { Card, Row, Col, Button, Spinner } from "react-bootstrap";
import Swal from "sweetalert2";
import api from "../../api/axiosConfig";

export default function ClienteServicios() {
  const [servicios, setServicios] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarServicios();
  }, []);

  const cargarServicios = async () => {
    setLoading(true);
    try {
      const res = await api.get("/servicios/"); // endpoint real
      // Normaliza estructura si backend devuelve campos con otros nombres
      const data = Array.isArray(res.data)
        ? res.data.map((s) => ({
            id: s.id_servicio ?? s.id ?? s.idService,
            nombre: s.nombre_servicio ?? s.nombre ?? s.name,
            descripcion: s.descripcion ?? s.desc ?? "",
            precio: s.precio_base ?? s.precio ?? 0,
            duracion: s.duracion_minutos ?? s.duracion ?? null,
          }))
        : [];
      setServicios(data);
    } catch (error) {
      console.error(error);
      Swal.fire("Error", error.response?.data?.detail || "No se pudieron cargar los servicios", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleAgendar = async (id) => {
    // Simple: usamos fecha actual como demo. Si tu UI pide fecha/hora, debes abrir modal para escoger.
    const confirm = await Swal.fire({
      title: "Agendar servicio",
      text: "¿Desea agendar este servicio ahora?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Sí, agendar",
      cancelButtonText: "Cancelar",
    });
    if (!confirm.isConfirmed) return;

    try {
      // Aquí enviamos POST. Backend actual espera POST /clientes/agendar/{id_servicio} (sin body en algunas versiones)
      // Pasamos un body con fecha para compatibilidad.
      const payload = { fecha: new Date().toISOString() };
      await api.post(`/clientes/agendar/${id}`, payload);
      Swal.fire("Éxito", "Servicio agendado correctamente", "success");
    } catch (error) {
      console.error(error);
      Swal.fire("Error", error.response?.data?.detail || "No se pudo agendar el servicio", "error");
    }
  };

  if (loading) return <Spinner animation="border" className="d-block mx-auto mt-5" />;

  return (
    <>
      <h4 className="fw-bold text-primary mb-4">Servicios Disponibles</h4>
      <Row>
        {servicios.length === 0 && (
          <div className="text-center text-muted">No hay servicios disponibles</div>
        )}
        {servicios.map((s) => (
          <Col md={4} key={s.id} className="mb-4">
            <Card className="shadow-sm border-0 h-100">
              <Card.Body className="d-flex flex-column">
                <div className="mb-3">
                  <Card.Title className="fw-semibold">{s.nombre}</Card.Title>
                  <Card.Text className="text-muted small">{s.descripcion}</Card.Text>
                </div>

                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <div>
                    <h6 className="text-success fw-bold mb-0">${(s.precio ?? 0).toLocaleString("es-CO")}</h6>
                    {s.duracion && <small className="text-muted d-block">{s.duracion} min</small>}
                  </div>
                  <Button variant="primary" size="sm" onClick={() => handleAgendar(s.id)}>
                    <i className="fas fa-calendar-plus me-2"></i> Agendar
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </>
  );
}
