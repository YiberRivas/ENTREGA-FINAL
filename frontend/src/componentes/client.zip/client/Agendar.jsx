import React, { useState, useEffect } from "react";
import { Container, Form, Button, Spinner } from "react-bootstrap";
import Swal from "sweetalert2";
import api from "../../api/axiosConfig";

export default function Agendar() {
  const [servicios, setServicios] = useState([]);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    persona_id: "",
    servicio_id: "",
    fecha: "",
    hora: "",
    horas_seleccionadas: 3, // mínimo 3 horas
    observaciones: "",
    forma_pago_id: 1,
  });

  // ==========================
  // Cargar servicios
  // ==========================
  useEffect(() => {
    const personaId = localStorage.getItem("persona_id");
    setFormData((f) => ({ ...f, persona_id: personaId }));

    cargarServicios();
  }, []);

  const cargarServicios = async () => {
    try {
      const res = await api.get("/servicios/");
      setServicios(res.data);
    } catch (error) {
      Swal.fire("Error", "No se pudieron cargar los servicios", "error");
    } finally {
      setLoading(false);
    }
  };

  // ==========================
  // Cambiar campos
  // ==========================
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ==========================
  // Enviar agendamiento
  // ==========================
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validar horario permitido
    const hour = parseInt(formData.hora.split(":")[0]);
    if (hour < 7 || hour >= 18) {
      Swal.fire(
        "Horario inválido",
        "La lavandería atiende de 7:00 AM a 6:00 PM",
        "warning"
      );
      return;
    }

    try {
      const data = {
        persona_id: Number(formData.persona_id),
        servicio_id: Number(formData.servicio_id),
        fecha: formData.fecha,
        hora: formData.hora + ":00",
        observaciones: formData.observaciones,
      };

      const res = await api.post("/agendamientos/", data);

      Swal.fire({
        title: "Agendado correctamente",
        text: "Tu servicio fue registrado. Espera a que el administrador lo inicie.",
        icon: "success",
        confirmButtonColor: "#17a2b8",
      });

      setFormData({
        ...formData,
        fecha: "",
        hora: "",
        observaciones: "",
      });

    } catch (error) {
      console.log(error);
      Swal.fire("Error", "No se pudo registrar el agendamiento", "error");
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center mt-5">
        <Spinner animation="border" />
      </div>
    );
  }

  return (
    <Container className="mt-4" style={{ maxWidth: "600px" }}>
      <h3 className="text-center mb-4">Agendar Servicio</h3>

      <Form onSubmit={handleSubmit}>
        {/* Servicio */}
        <Form.Group className="mb-3">
          <Form.Label>Seleccionar Servicio</Form.Label>
          <Form.Select
            name="servicio_id"
            value={formData.servicio_id}
            onChange={handleChange}
            required
          >
            <option value="">Seleccione...</option>
            {servicios.map((s) => (
              <option key={s.id_servicio} value={s.id_servicio}>
                {s.nombre_servicio} — ${s.precio_base}
              </option>
            ))}
          </Form.Select>
        </Form.Group>

        {/* Fecha */}
        <Form.Group className="mb-3">
          <Form.Label>Fecha</Form.Label>
          <Form.Control
            type="date"
            name="fecha"
            value={formData.fecha}
            onChange={handleChange}
            required
          />
        </Form.Group>

        {/* Hora */}
        <Form.Group className="mb-3">
          <Form.Label>Hora de inicio</Form.Label>
          <Form.Control
            type="time"
            name="hora"
            value={formData.hora}
            onChange={handleChange}
            required
          />
          <small className="text-muted">
            Horario permitido: 7:00 AM a 6:00 PM
          </small>
        </Form.Group>

        {/* Observaciones */}
        <Form.Group className="mb-3">
          <Form.Label>Observaciones (opcional)</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            name="observaciones"
            value={formData.observaciones}
            onChange={handleChange}
          />
        </Form.Group>

        {/* Método de pago */}
        <Form.Group className="mb-4">
          <Form.Label>Método de Pago</Form.Label>
          <Form.Select
            name="forma_pago_id"
            value={formData.forma_pago_id}
            onChange={handleChange}
          >
            <option value="1">Efectivo</option>
            <option value="2">Tarjeta</option>
            <option value="3">PSE</option>
            <option value="4">Nequi/Daviplata</option>
          </Form.Select>
        </Form.Group>

        <Button type="submit" variant="info" className="w-100">
          Agendar
        </Button>
      </Form>
    </Container>
  );
}
