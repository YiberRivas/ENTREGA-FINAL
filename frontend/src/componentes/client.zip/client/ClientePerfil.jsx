// src/pages/cliente/ClientePerfil.jsx
import { useState, useEffect } from "react";
import { Card, Row, Col, Button, Form } from "react-bootstrap";
import Swal from "sweetalert2";
import api from "../../api/axiosConfig";

export default function ClientePerfil() {
  const [usuarioLocal, setUsuarioLocal] = useState(null);
  const [editando, setEditando] = useState(false);
  const [formData, setFormData] = useState({
    nombres: "",
    apellidos: "",
    correo: "",
    telefono: "",
    direccion: ""
  });

  useEffect(() => {
    const user = localStorage.getItem("usuario");
    if (user) {
      const u = JSON.parse(user);
      setUsuarioLocal(u);
      // Para mejor compatibilidad, carga valores si vienen
      setFormData({
        nombres: u.nombre?.split(" ")[0] || "",
        apellidos: u.nombre?.split(" ").slice(1).join(" ") || "",
        correo: u.correo || "",
        telefono: u.telefono || "",
        direccion: u.direccion || ""
      });
    }
  }, []);

  const handleChange = (e) => {
    setFormData((s) => ({ ...s, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Petición PUT al endpoint real
      const payload = {
        nombres: formData.nombres,
        apellidos: formData.apellidos,
        correo: formData.correo,
        telefono: formData.telefono,
        direccion: formData.direccion
      };
      const res = await api.put("/clientes/perfil", payload);
      // Actualizar localStorage.usuario si backend devuelve la persona (o normalizar)
      const updatedPersona = res.data.persona || res.data || payload;
      const usuario = JSON.parse(localStorage.getItem("usuario") || "{}");
      usuario.nombre = `${updatedPersona.nombres || formData.nombres} ${updatedPersona.apellidos || formData.apellidos}`.trim();
      usuario.correo = updatedPersona.correo || formData.correo;
      usuario.telefono = updatedPersona.telefono || formData.telefono;
      localStorage.setItem("usuario", JSON.stringify(usuario));

      setUsuarioLocal(usuario);
      Swal.fire("Éxito", "Perfil actualizado correctamente", "success");
      setEditando(false);
    } catch (error) {
      console.error(error);
      Swal.fire("Error", error.response?.data?.detail || "No se pudo actualizar el perfil", "error");
    }
  };

  return (
    <div className="cliente-perfil">
      <h2 className="mb-4">Mi Perfil</h2>

      <Row>
        <Col lg={8}>
          <Card className="shadow-sm">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">Información Personal</h5>
            </Card.Header>
            <Card.Body>
              {!editando ? (
                <>
                  <Row className="mb-3">
                    <Col md={6}>
                      <strong>Nombre de usuario:</strong>
                      <p>{usuarioLocal?.usuario}</p>
                    </Col>
                    <Col md={6}>
                      <strong>Nombre completo:</strong>
                      <p>{usuarioLocal?.nombre}</p>
                    </Col>
                  </Row>
                  <Row className="mb-3">
                    <Col md={6}>
                      <strong>Correo electrónico:</strong>
                      <p>{usuarioLocal?.correo || "No registrado"}</p>
                    </Col>
                    <Col md={6}>
                      <strong>Rol:</strong>
                      <p className="text-capitalize">{usuarioLocal?.rol || "cliente"}</p>
                    </Col>
                  </Row>
                  <Row className="mb-3">
                    <Col md={6}>
                      <strong>Teléfono:</strong>
                      <p>{usuarioLocal?.telefono || "No registrado"}</p>
                    </Col>
                    <Col md={6}>
                      <strong>Estado:</strong>
                      <p>
                        <span className={`badge ${usuarioLocal?.activo ? "bg-success" : "bg-danger"}`}>
                          {usuarioLocal?.activo ? "Activo" : "Inactivo"}
                        </span>
                      </p>
                    </Col>
                  </Row>
                  <Button variant="primary" onClick={() => setEditando(true)}>
                    Editar Perfil
                  </Button>
                </>
              ) : (
                <Form onSubmit={handleSubmit}>
                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Nombres</Form.Label>
                        <Form.Control name="nombres" value={formData.nombres} onChange={handleChange} required />
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Apellidos</Form.Label>
                        <Form.Control name="apellidos" value={formData.apellidos} onChange={handleChange} required />
                      </Form.Group>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Correo electrónico</Form.Label>
                        <Form.Control type="email" name="correo" value={formData.correo} onChange={handleChange} required />
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Teléfono</Form.Label>
                        <Form.Control type="tel" name="telefono" value={formData.telefono} onChange={handleChange} />
                      </Form.Group>
                    </Col>
                  </Row>

                  <Form.Group className="mb-3">
                    <Form.Label>Dirección</Form.Label>
                    <Form.Control name="direccion" value={formData.direccion} onChange={handleChange} />
                  </Form.Group>

                  <div className="d-flex gap-2">
                    <Button variant="success" type="submit">Guardar</Button>
                    <Button variant="secondary" onClick={() => setEditando(false)}>Cancelar</Button>
                  </div>
                </Form>
              )}
            </Card.Body>
          </Card>
        </Col>

        <Col lg={4}>
          <Card className="shadow-sm mb-3">
            <Card.Header className="bg-info text-white">
              <h6 className="mb-0">Resumen</h6>
            </Card.Header>
            <Card.Body>
              <div className="mb-3">
                <small className="text-muted">Servicios contratados</small>
                <h3 className="mb-0">0</h3>
              </div>
              <div className="mb-3">
                <small className="text-muted">Agendamientos activos</small>
                <h3 className="mb-0">0</h3>
              </div>
              <div>
                <small className="text-muted">Última actividad</small>
                <p className="mb-0">Hoy</p>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
