import React, { useEffect, useState, useRef } from "react";
import { Container, Table, Button, Badge } from "react-bootstrap";
import api from "../../api/axiosConfig";
import Swal from "sweetalert2";

function formatoDuracion(segundos) {
  const horas = Math.floor(segundos / 3600);
  const minutos = Math.floor((segundos % 3600) / 60);
  const secs = Math.floor(segundos % 60);
  return `${String(horas).padStart(2,"0")}:${String(minutos).padStart(2,"0")}:${String(secs).padStart(2,"0")}`;
}

export default function ClienteAgendamientos() {
  const [agendamientos, setAgendamientos] = useState([]);
  const [loading, setLoading] = useState(true);
  const timersRef = useRef({});

  useEffect(() => {
    cargar();
    const interval = setInterval(() => cargar(), 10000); // refrescar cada 10s
    return () => clearInterval(interval);
  }, []);

  const cargar = async () => {
    setLoading(true);
    try {
      const res = await api.get("/cliente/historial"); // si tienes endpoint distinto, modifícalo
      // Aquí espero que res.data.historial o similar venga; ajusta según tu API
      const data = res.data.historial || res.data || [];
      setAgendamientos(data);
    } catch (err) {
      console.error(err);
      Swal.fire("Error", "No se pudo cargar tus agendamientos", "error");
    } finally {
      setLoading(false);
    }
  };

  const handlePagar = async (id_factura) => {
    const { value: forma } = await Swal.fire({
      title: "Selecciona forma de pago",
      input: "select",
      inputOptions: {
        1: "Efectivo",
        2: "Tarjeta",
        3: "PSE",
        4: "Nequi/Daviplata"
      },
      showCancelButton: true
    });
    if (!forma) return;

    try {
      await api.post(`/facturas/${id_factura}/pagar`, { forma_pago_id: Number(forma) });
      Swal.fire("Éxito", "Pago realizado correctamente", "success");
      cargar();
    } catch (err) {
      console.error(err);
      Swal.fire("Error", err.response?.data?.detail || "No se pudo procesar el pago", "error");
    }
  };

  if (loading) return <div className="text-center py-5">Cargando...</div>;

  return (
    <Container fluid>
      <h4 className="mb-3">Mis Agendamientos</h4>
      <Table hover responsive>
        <thead>
          <tr>
            <th>ID</th>
            <th>Servicio</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Duración</th>
            <th>Factura</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {agendamientos.length === 0 ? (
            <tr>
              <td colSpan="7" className="text-center">No hay agendamientos</td>
            </tr>
          ) : (
            agendamientos.map((a, i) => {
              const factura = a.factura || null;
              return (
                <tr key={i}>
                  <td>#{a.id_agendamiento || a.id}</td>
                  <td>{a.servicio?.nombre_servicio || a.servicio}</td>
                  <td>{a.fecha}</td>
                  <td>
                    <Badge bg={a.estado === "finalizado" ? "success" : a.estado === "en_proceso" ? "info" : "secondary"}>
                      {a.estado}
                    </Badge>
                  </td>
                  <td>{a.duracion || "-"}</td>
                  <td>{factura ? `$ ${factura.total}` : "-"}</td>
                  <td>
                    {factura && factura.estado && factura.estado.toLowerCase().includes("pag") ? (
                      <span className="text-success">Pagada</span>
                    ) : factura ? (
                      <Button size="sm" variant="success" onClick={() => handlePagar(factura.id_factura)}>Pagar</Button>
                    ) : (
                      <small className="text-muted">Sin factura</small>
                    )}
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </Table>
    </Container>
  );
}
