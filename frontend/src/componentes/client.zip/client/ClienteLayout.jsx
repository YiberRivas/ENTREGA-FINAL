// src/pages/cliente/ClienteLayout.jsx
import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { Container, Nav, Navbar, Dropdown } from "react-bootstrap";
import { useState, useEffect } from "react";
import Swal from "sweetalert2";

export default function ClienteLayout() {
  const [usuario, setUsuario] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("usuario");
    if (userData) setUsuario(JSON.parse(userData));
  }, []);

  const handleLogout = () => {
    Swal.fire({
      title: "¿Cerrar sesión?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc3545",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Sí, salir",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.removeItem("token");
        localStorage.removeItem("usuario");
        navigate("/inicio");
      }
    });
  };

  return (
    <div className="cliente-layout">
      <Navbar bg="dark" variant="dark" expand="lg" className="mb-0">
        <Container fluid>
          <Navbar.Brand as={NavLink} to="/cliente">
            <i className="bi bi-person-circle me-2"></i> Portal Cliente
          </Navbar.Brand>

          <Navbar.Toggle aria-controls="navbar-cliente" />
          <Navbar.Collapse id="navbar-cliente">
            <Nav className="me-auto">
              <Nav.Link as={NavLink} to="/cliente/perfil">
                Mi Perfil
              </Nav.Link>
              <Nav.Link as={NavLink} to="/cliente/servicios">
                Servicios
              </Nav.Link>
              <Nav.Link as={NavLink} to="/cliente/agendamientos">
                Mis Agendamientos
              </Nav.Link>
              <Nav.Link as={NavLink} to="/cliente/historial">
                Historial
              </Nav.Link>
            </Nav>

            <Dropdown align="end">
              <Dropdown.Toggle variant="outline-light" id="dropdown-usuario">
                {usuario?.nombre || usuario?.usuario || "Usuario"}
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item disabled>
                  <small className="text-muted d-block">{usuario?.correo}</small>
                </Dropdown.Item>
                <Dropdown.Divider />
                <Dropdown.Item onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right me-2"></i>Cerrar sesión
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <div className="cliente-content">
        <Container fluid className="py-4">
          <Outlet />
        </Container>
      </div>
    </div>
  );
}
