# app/rutas/clientes.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.config.database import get_db
from app.modelos.modelos import Usuario, Persona, Servicio, Agendamiento
from app.seguridad import get_current_user

router = APIRouter(prefix="/clientes", tags=["Clientes"])

# =======================================
# 🧍 PERFIL DEL CLIENTE
# =======================================
@router.get("/perfil")
def obtener_perfil(
    usuario_actual: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    persona = db.query(Persona).filter(Persona.id_persona == usuario_actual.persona_id).first()
    if not persona:
        raise HTTPException(status_code=404, detail="Perfil no encontrado")
    return persona


@router.put("/perfil")
def actualizar_perfil(
    datos: dict,
    usuario_actual: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    persona = db.query(Persona).filter(Persona.id_persona == usuario_actual.persona_id).first()
    if not persona:
        raise HTTPException(status_code=404, detail="Perfil no encontrado")

    for campo, valor in datos.items():
        if hasattr(persona, campo) and valor is not None:
            setattr(persona, campo, valor)

    db.commit()
    db.refresh(persona)
    return {"mensaje": "Perfil actualizado correctamente"}

# =======================================
# 🧾 AGENDAR SERVICIO
# =======================================
@router.post("/agendar/{id_servicio}")
def agendar_servicio(
    id_servicio: int,
    usuario_actual: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    servicio = db.query(Servicio).filter(Servicio.id_servicio == id_servicio).first()
    if not servicio:
        raise HTTPException(status_code=404, detail="Servicio no encontrado")

    nuevo_agendamiento = Agendamiento(
        persona_id=usuario_actual.persona_id,
        servicio_id=id_servicio,
        estado="pendiente"
    )
    db.add(nuevo_agendamiento)
    db.commit()
    return {"mensaje": "Servicio agendado correctamente"}

# =======================================
# 📜 HISTORIAL DE SERVICIOS
# =======================================
@router.get("/historial")
def historial_servicios(
    usuario_actual: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    agendamientos = (
        db.query(Agendamiento, Servicio)
        .join(Servicio, Servicio.id_servicio == Agendamiento.servicio_id)
        .filter(Agendamiento.persona_id == usuario_actual.persona_id)
        .all()
    )

    resultado = [
        {
            "servicio": s.nombre,
            "fecha": str(a.fecha) if a.fecha else "Sin fecha",
            "estado": a.estado,
            "total": s.precio
        }
        for a, s in agendamientos
    ]
    return resultado
